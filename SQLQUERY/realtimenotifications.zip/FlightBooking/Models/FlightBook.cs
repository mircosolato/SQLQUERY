﻿namespace FlightBooking.Models
{
    public class FlightBookViewModel
    {
        public int Id { get; set; }
        public int Seats { get; set; }
    }
}